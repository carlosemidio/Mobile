package com.example.emersonalencar.exercicio01aula07;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TableLayout;
import android.widget.TextView;

public class MainActivity extends Activity {

    private EditText txtNome;
    private RadioGroup grpSexo;
    private TextView txtNomeDigitado;
    private TextView txtSexoDigitado;
    private ViewGroup layTable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        txtNome = findViewById(R.id.txt_form_nome);
        grpSexo = findViewById(R.id.grp_form_sexo);
        txtNomeDigitado = findViewById(R.id.txt_nome_digitado);
        txtSexoDigitado = findViewById(R.id.txt_sexo_digitado);
        layTable = findViewById(R.id.lay_result);
    }

    public void exibir(View v) {
        //Exibe a tabela inferior, que inicialmente fica invisível
        layTable.setVisibility(TableLayout.VISIBLE);

        //Lê o nome digitado
        String nome = txtNome.getText().toString();

        //Retorna o ID do radio button selecionado
        int sexo = grpSexo.getCheckedRadioButtonId();

        //Copia o nome para a caixa de texto
        txtNomeDigitado.setText(nome);

        //Converte o radio button selecionado para texto.
        //O método getString() retorna a string do arquivos de recursos XML com base no seu ID.
        //Depois de lida, ela é copiada para a caixa de texto.
        if (sexo == R.id.rad_masc) {
            String texto = getString(R.string.masc);
            txtSexoDigitado.setText(texto);

        } else if (sexo == R.id.rad_fem) {
            String texto = getString(R.string.fem);
            txtSexoDigitado.setText(texto);
        }
    }

    public void limpar(View v) {
        //Retorna todas as informações da tela para o seu estado inicial
        txtNome.setText(null);
        grpSexo.clearCheck();
        txtNomeDigitado.setText(null);
        txtSexoDigitado.setText(null);
        layTable.setVisibility(TableLayout.INVISIBLE);
    }
}
