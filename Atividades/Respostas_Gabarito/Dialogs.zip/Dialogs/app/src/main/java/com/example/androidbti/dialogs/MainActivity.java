package com.example.androidbti.dialogs;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void open(View view) {

        MyDialog myDialog = new MyDialog();
        myDialog.show(getFragmentManager(),"mydialog");
    }

    public void openSimples(View view) {
        SimpleDialogFragment simpleDialogFragment = new SimpleDialogFragment();
        simpleDialogFragment.show(getFragmentManager(),"openSimples");
    }

    public void openRadio(View view) {
        RadioDialogFragment radio = new RadioDialogFragment();
        radio.show(getFragmentManager(),"radioSimples");
    }

    public void openMulti(View view) {
        MultiDialogFragment multi = new MultiDialogFragment();
        multi.show(getFragmentManager(),"MultiSimples");
    }
}
