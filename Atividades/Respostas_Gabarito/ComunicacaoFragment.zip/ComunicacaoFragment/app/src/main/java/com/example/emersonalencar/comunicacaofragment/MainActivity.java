package com.example.emersonalencar.comunicacaofragment;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity implements TextFragment.OnInvertListener{

    private ResultFragment resultFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        resultFragment =  (ResultFragment) getFragmentManager().findFragmentById(R.id.frag_result);
    }

    @Override
    public void onInvert(String text) {

            resultFragment.invert(text);

    }
}
