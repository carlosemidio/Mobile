package com.example.emersonalencar.exemploprogressbar;

import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView txtContent;
    private ProgressBar progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtContent = findViewById(R.id.txt_content);
        progress = findViewById(R.id.progress);

        txtContent.setVisibility(View.GONE);

        new Thread(new Runnable() {
            @Override
            public void run() {
                SystemClock.sleep(5000);

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                            showContent();
                    }
                });
            }
        }).start();
    }


    private void showContent(){

        txtContent.setVisibility(View.VISIBLE);
        progress.setVisibility(View.GONE);


    }
}
