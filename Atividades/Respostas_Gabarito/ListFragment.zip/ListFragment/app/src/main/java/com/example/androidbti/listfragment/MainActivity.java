package com.example.androidbti.listfragment;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements AlimentosFragment.OnItemClick {

    private TextFragment textFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textFragment = (TextFragment) getFragmentManager().findFragmentById(R.id.frag_text);

    }

    @Override
    public void onClickAlimento(Alimento alimento) {
        textFragment.setText("O preço do "+alimento.getNome()+" é: R$ "+alimento.getPreco());
    }
}
