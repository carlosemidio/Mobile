package com.example.androidbti.pickers;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.os.Bundle;
import android.widget.Toast;

/**
 * Created by android.bti on 24/04/18.
 */

public class DatePicker extends DialogFragment implements DatePickerDialog.OnDateSetListener{

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        return new DatePickerDialog(getActivity(),this,2018,3,24);
    }

    @Override
    public void onDateSet(android.widget.DatePicker view, int year, int month, int dayOfMonth) {
        String msg =
                String.format("Você escolheu a data %02d/%02d/%d",dayOfMonth,month,year);

        Toast.makeText(getActivity(),msg, Toast.LENGTH_SHORT).show();
    }
}
