package com.example.androidbti.exemplorecyclerview;

/**
 * Created by android.bti on 26/04/18.
 */

public class Item {
    private int id;
    private String nome;

    public Item(int id, String nome){
        this.id = id;
        this.nome = nome;
    }

    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }
}
