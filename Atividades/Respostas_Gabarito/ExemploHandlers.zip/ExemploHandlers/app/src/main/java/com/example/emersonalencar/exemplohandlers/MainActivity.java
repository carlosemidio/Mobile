package com.example.emersonalencar.exemplohandlers;

import android.app.Activity;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {

    private TextView textView;
    private Button btnProcessar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.txt_status);
        btnProcessar = findViewById(R.id.btn_processar);

    }


    public void processar(View view) {
        textView.setText(R.string.processando);
        btnProcessar.setEnabled(false);
        executarAlgoDemorado();

    }


    private void executarAlgoDemorado() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                SystemClock.sleep(10000);

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        textView.setText(R.string.finalizado);
                        btnProcessar.setEnabled(true);
                    }
                });
            }
        }).start();
    }
}
