package com.example.carlosemidio.aula6_atividade_calculadora_imc;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Button btnPeso;
    private Button btnAltura;
    private Button btnCalcular;
    private TextView peso;
    private TextView altura;
    private TextView resultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.btnPeso = findViewById(R.id.altPeso);
        this.btnAltura = findViewById(R.id.altAltura);
        this.btnCalcular = findViewById(R.id.calcula);
        this.peso = findViewById(R.id.peso);
        this.altura = findViewById(R.id.altura);
        this.resultado = findViewById(R.id.resultado);
    }

    public void altPeso(View view) {
        // Intent que chama a subActivity
        Intent it = new Intent(getApplicationContext(), Main2Activity.class);
        // Pacote que passa parâmetros para a subActivity
        Bundle params = new Bundle();
        params.putInt("code", 1);
        it.putExtras(params);
        startActivityForResult(it, 1);
    }

    public void calcula(View view) {
        float peso = Float.parseFloat(this.peso.getText().toString().split(" ")[1]);
        float altura = Float.parseFloat(this.altura.getText().toString().split(" ")[1]);

        if (peso != 0) {
            if (altura != 0) {
                float imc = (peso/((altura)*(altura)));
                this.resultado.setText("IMC: "+imc);
            } else {
                this.resultado.setText("Informe o peso!");
            }
        } else {
            this.resultado.setText("Informe o peso!");
        }
    }

    public void altAltura(View view) {
        // Intent que chama a subActivity
        Intent it = new Intent(getApplicationContext(), Main2Activity.class);
        // Pacote que passa parâmetros para a subActivity
        Bundle params = new Bundle();
        params.putInt("code", 2);
        it.putExtras(params);
        startActivityForResult(it, 1);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
                Bundle params =  data.getExtras();
                if (params.getInt("code") == 1) {
                    this.peso.setText("Peso: "+Float.parseFloat(params.getString("valor"))+" kg");
                } else if (params.getInt("code") == 2) {
                    this.altura.setText("Altura: "+Float.parseFloat(params.getString("valor"))+" m");
                }
            }
        }
    }
}
