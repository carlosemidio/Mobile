package com.example.carlosemidio.aula6_atividade_calculadora_imc;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {
    private Button btnAlt;
    private Button btnCan;
    private EditText valor;
    private TextView txtTitulo;
    private int code;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        this.btnAlt = findViewById(R.id.alterar);
        this.btnCan = findViewById(R.id.cancelar);
        this.valor = findViewById(R.id.valor);
        this.txtTitulo = findViewById(R.id.titulo);
        Intent it = getIntent();
        Bundle params = it.getExtras();
        this.code = params.getInt("code");

        if(this.code == 1) {
            this.txtTitulo.setText("Peso");
        } else if (this.code == 2) {
            this.txtTitulo.setText("Altura");
        }
    }

    public void cancelar(View view) {
        finish();
    }

    public void alterar(View view) {
        Intent data = new Intent();
        Bundle params = new Bundle();
        params.putString("valor", this.valor.getText().toString());
        params.putInt("code", this.code);
        data.putExtras(params);
        setResult(RESULT_OK, data);
        finish();
    }
}
