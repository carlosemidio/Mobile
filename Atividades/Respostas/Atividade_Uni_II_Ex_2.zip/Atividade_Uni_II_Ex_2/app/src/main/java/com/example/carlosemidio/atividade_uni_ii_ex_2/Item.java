package com.example.carlosemidio.atividade_uni_ii_ex_2;

public class Item {
    private String titulo;

    public Item(String titulo) {
        this.titulo = titulo;
    }

    public String getTitulo() {
        return titulo;
    }
}
