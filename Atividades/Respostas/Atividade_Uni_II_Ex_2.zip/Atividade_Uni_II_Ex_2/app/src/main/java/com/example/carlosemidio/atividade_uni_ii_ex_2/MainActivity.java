package com.example.carlosemidio.atividade_uni_ii_ex_2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private MyAdapter adapter;
    private List<Item> itemsList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        this.recyclerView.setHasFixedSize(true);
        this.recyclerView.setLayoutManager(new LinearLayoutManager(this));

        this.itemsList = new ArrayList<>();

        for (int i = 1; i < 51; i++) {
            this.itemsList.add(new Item(""+i));
        }

        this.adapter = new MyAdapter(this.itemsList, this);
        this.recyclerView.setAdapter(this.adapter);
    }
}
