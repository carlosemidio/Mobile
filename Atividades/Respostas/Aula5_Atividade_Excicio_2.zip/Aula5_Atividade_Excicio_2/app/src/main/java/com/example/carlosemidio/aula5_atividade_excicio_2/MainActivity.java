package com.example.carlosemidio.aula5_atividade_excicio_2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.i("onCreate", "Ativity está sendo criada");
    }

    @Override
    protected void onStart() {
        super.onStart();
        // The activity is about to become visible.
        Log.i("onStart", "Ativity está sendo iniciada");
    }
    @Override
    protected void onResume() {
        super.onResume();
        // The activity has become visible (it is now "resumed").
        Log.i("onResume", "Ativity irá rodar");
    }
    @Override
    protected void onPause() {
        super.onPause();
        // Another activity is taking focus (this activity is about to be "paused").
        Log.i("onPause", "Ativity será pausada");
    }
    @Override
    protected void onStop() {
        super.onStop();
        // The activity is no longer visible (it is now "stopped")
        Log.i("onStop", "Ativity irá parar");
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i("onDestroy", "Ativity será destruída");
        // The activity is about to be destroyed.
    }
}
